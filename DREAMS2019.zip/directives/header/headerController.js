appHISPColombia.directive('d2Header', function(){
return{
	restrict: 'E',
	templateUrl: 'directives/header/headerView.html'
}
})